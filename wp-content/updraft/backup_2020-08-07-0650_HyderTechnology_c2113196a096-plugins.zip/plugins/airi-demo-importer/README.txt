=== Airi Demo Importer ===
Contributors: athemes, vladff
Tags: demo content
Requires at least: 4.0
Tested up to: 5.4
Stable tag: 1.0.3
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Registers custom post types and custom fields for the Sydney theme

== Description ==

**The Airi Demo Importer plugin is meant to be used only with the Airi WordPress theme.**

This sets up the demo content configuration for the [Airi theme](http://wordpress.org/themes/airi/)

== Installation ==

1. Go to Plugins > Add New and search for Airi Demo Importer. Install and activate it.
2. That's it. No configuration needed.

== Frequently Asked Questions ==

None yet.

== Screenshots ==

== Changelog ==

= 1.0.3 =
* Added new Photography demo

= 1.0.2 =
* Changed function names to prevent conflicts with older versions of the theme

= 1.0.1 =
* Updated readme

= 1.0.0 =
* Initial version