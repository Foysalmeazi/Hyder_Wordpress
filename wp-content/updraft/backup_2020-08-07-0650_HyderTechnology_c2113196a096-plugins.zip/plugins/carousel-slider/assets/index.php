<?php
// Code is Poetry